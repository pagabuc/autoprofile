def test_import():
    import archinfo
