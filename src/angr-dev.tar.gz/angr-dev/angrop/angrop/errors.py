class RegNotFoundException(Exception):
    pass


class RopException(Exception):
    pass
