from . import ExplorationTechnique
import random

from collections import defaultdict

class Coverage(ExplorationTechnique):
    """
    Depth-first search.

    Will only keep one path active at a time, any others will be stashed in the 'deferred' stash.
    When we run out of active paths to step, we take the longest one from deferred and continue.
    """

    def __init__(self, threshold):
        super(Coverage, self).__init__()
        # self.already_seen = []
        self.already_seen = defaultdict(int)
        self.threshold = threshold
        
    def step(self, simgr, stash='active', **kwargs):
        # print("[coverage] step was called with: %s actives\n" % simgr.stashes[stash])
        return simgr.step(stash=stash, **kwargs)
    
    def filter(self, simgr, state, **kwargs):
        # print("filter: %s" % hex(state.addr))

        if state.globals.get("noskip"):
            # print("state belongs to a function call, not filtering")
            del state.globals["noskip"]
            return 'active'
        
        # if self.already_seen.count(state.addr) == self.threshold:
        if self.already_seen[state.addr] == self.threshold:
            # print("state already seen, discarding it\n")
            return 'deadended'
        else:
            self.already_seen[state.addr] += 1
            # self.already_seen.append(state.addr)
            return 'active'

    def step_state(self, simgr, state, **kwargs):
        # print("[coverage] step_state: %s" % (state))
        try:
            step = simgr.step_state(state, **kwargs)
        except RecursionError:
            return {}

        # print("[coverage] simgr.step_state returned: %s" % step)
        if None in step.keys():
            step[None] += step['unsat']
            step['unsat'] = []                
        # print("[coverage] we return: %s\n" % step)        
        return step
