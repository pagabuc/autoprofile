
import angr

######################################
# openlog
######################################

class closelog(angr.SimProcedure):
    #pylint:disable=arguments-differ

    def run(self, ident, option, facility):
        # A stub for closelog that does not do anything yet.
        return
