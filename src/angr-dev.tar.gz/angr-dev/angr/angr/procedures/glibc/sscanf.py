from ..libc.sscanf import sscanf

class __isoc99_sscanf(sscanf):
    pass
