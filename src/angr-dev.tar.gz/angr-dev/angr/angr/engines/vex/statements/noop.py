def SimIRStmt_NoOp(_engine, _stmt, _state):
    pass
