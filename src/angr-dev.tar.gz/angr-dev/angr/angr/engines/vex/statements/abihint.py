def SimIRStmt_AbiHint(_engine, _state, _stmt):
    pass
