def SimIRStmt_MBE(_engine, _state, _stmt):
    pass
