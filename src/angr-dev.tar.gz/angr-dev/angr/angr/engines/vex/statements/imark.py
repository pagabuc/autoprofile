def SimIRStmt_IMark(_engine, state, _stmt):
    state.history.recent_instruction_count += 1
