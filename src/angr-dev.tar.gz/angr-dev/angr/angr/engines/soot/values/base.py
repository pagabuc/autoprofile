
class SimSootValue:

    @classmethod
    def from_sootvalue(cls, soot_value, state):
        raise NotImplementedError()
