
class BlockTerminationNotice(Exception):
    pass

class IncorrectLocationException(Exception):
    pass

class SootMethodNotLoadedException(Exception):
    pass

class SootFieldNotLoadedException(Exception):
    pass
